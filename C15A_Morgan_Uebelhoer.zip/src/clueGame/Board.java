//Authors: Brendan Uebelhoer, Ben Morgan
package clueGame;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class Board {

	// number of rows in the board
	private int numRows;

	// number of column in the board
	private int numCols;

	//stores the cells visited. used in target finding algorithm
	private Set<BoardCell> visited;

	//stores the board itself
	private BoardCell[][] board;

	//stores the movable cells
	private Set<BoardCell> targets;

	//maps the character symbol of a room to the room object itself
	private Map<Character,Room> roomMap;

	//strings that hold the filename of the config files.
	private String layoutConfigFile, setupConfigFile;

	//specific instance of the board
	private static Board instance = new Board();

	// constructor is private to ensure only one can be created
	private Board() {
		super();
	}

	// this method returns the only Board
	public static Board getInstance() {
		return instance;
	}

	//initialize board
	public void initialize() {
		// BadCOnfigException indicates invalid format in the config files
		try {
			//loads the setup file
			loadSetupConfig();
			//loads the config file
			loadLayoutConfig();
		} catch (BadConfigFormatException e) {
			System.out.println(e.getMessage());
		}

		// allocates the visited and target sets
		visited = new HashSet<BoardCell>();
		targets = new HashSet<BoardCell>();

		//generates the list of adjacencies for each cell
		generateAdjacencies();
	}

	//Creates a map which stores what cells are adjacent to each other
		private void generateAdjacencies() {    
			
			for (int i = 0; i < numRows; i++) {
				for (int j = 0; j < numCols; j++) {

					//logic makes sure it doesn't add a cell that is off the board
					if (checkCell(i - 1, j)) {
						board[i][j].addAdjacency(board[i-1][j]);
					}
					
					if (checkCell(i + 1, j)) {
						board[i][j].addAdjacency(board[i+1][j]);
					}

					if (checkCell(i, j - 1)) {
						board[i][j].addAdjacency(board[i][j-1]);
					}

					if (checkCell(i, j + 1)) {
						board[i][j].addAdjacency(board[i][j+1]);
					}
				
					if (board[i][j].isDoorway()) {
						board[i][j].addAdjacency(getDoorDest(i, j));
					}
					if (board[i][j].isSecretPassage()) {
						board[i][j].addAdjacency(getSecretPassageDest(i, j));
					}
					if (board[i][j].isRoomCenter()) {
						//adds each doorway cell to the adj
						for (BoardCell c :board[i][j].getRoom().getDoorways()) {
							board[i][j].addAdjacency(c);
						}
					}
				}
			}
		}

	private BoardCell getSecretPassageDest(int i, int j) {
		BoardCell cell = board[i][j];
		Room passageRoom = roomMap.get(cell.getSecretPassage());
		BoardCell passageCell = passageRoom.getCenterCell();
		return passageCell;
	}

		private BoardCell getDoorDest(int i, int j) {
			//default initializes to UP direction to be overwritten later if needed
			BoardCell cell = board[i-1][j];
			
			//gets cell in door direction to get room from
			switch(board[i][j].getDoorDirection()) {
			case UP:
				//this is the default case, so nothing is done
				break;
			case DOWN:
				cell = board[i+1][j];
				break;
			case LEFT:
				cell = board[i][j-1];
				break;
			case RIGHT:
				cell = board[i][j+1];
				break;
			}
			
			//returns destination cell
			return cell.getRoom().getCenterCell();
		}

	//checks if a cell is a valid cell to add to the adjacency list
	private boolean checkCell(int y, int x) {
		//if the row is within the board
		if(y < 0 || y >= numRows) {
			return false;
		}
		//if the col is within the board
		if (x < 0 || x >= numCols) {
			return false;
		}
		//if the cell is an unused cell
		if (checkUnused(y,x)) {
			return false;
		}
		//if the cell is a room
		if (board[y][x].isRoom()) {
			return false;
		}
		//if none of the previous conditions are true, the cell is assumed to be valid
		return true;
	}
	
	private boolean checkUnused(int y, int x) {
		return board[y][x].getRoom() == roomMap.get('X');
	}
	
	//calculates valid targets to move to from the given location
	public void calcTargets( BoardCell startCell, int pathlength) { //fills targets with all possible moves
		targets.clear();
		calcTargetsRecursive(startCell, pathlength, startCell);
	}

	private void calcTargetsRecursive(BoardCell currentCell, int pathlength, BoardCell startCell) {
		//Base Case
		//if cell is occupied, cannot move to it
		if (currentCell.isOccupied() && !currentCell.isRoomCenter()) { 
			return;
		}
		//Base Case
		//if cell is already visited, cannot move to it
		if (visited.contains(currentCell)) { 
			return;
		}

		//Base Case
		// no moves left, add current cell to targets
		if(pathlength == 0) { 
			targets.add(currentCell);	

			//Base Case
			// if given cell is a room, all moves used up, and added to targets
		} else if (currentCell.isRoom() && !currentCell.equals(startCell)) { 
			targets.add(currentCell);
			//Recursive Case
		} else {
			// add cell to visited
			visited.add(currentCell);

			//recursively calls calcTargets() on every adjacent cell
			for (BoardCell c: currentCell.getAdjList()) {
				calcTargetsRecursive(c, pathlength - 1, startCell);
			}
			// removes cell from visited after all paths forward have been explore
			visited.remove(currentCell); 
		}
	}

	public void loadSetupConfig() throws BadConfigFormatException {
		// allocates the map. uses HashMap as order doesn't matter 
		roomMap = new HashMap<Character, Room>();
		try {
			FileReader reader = new FileReader(setupConfigFile);
			Scanner scanner = new Scanner(reader);


			while (scanner.hasNextLine()) {
				String data = scanner.nextLine(); // first element of a line should be what type it is.

				if (data.charAt(0) == '/' && data.charAt(1) == '/') {
					continue;
				}

				int commaIndex = data.indexOf(',');
				String dataType = data.substring(0, commaIndex);
				data = data.substring(commaIndex+1);
				data = data.stripLeading();

				switch (dataType) {
				case "Room":
				case "Space":
				{
					addRoom(data);
					break;
				}
				default:
					throw new BadConfigFormatException();
				}


			}
		}
		catch (FileNotFoundException e) {
			System.out.println(e);
		}

	}

	private void addRoom(String data) {
		int commaIndex;
		commaIndex = data.indexOf(',');
		String roomName = data.substring(0,commaIndex);
		data = data.substring(commaIndex+1);
		data = data.stripLeading();
		char roomSymbol = data.charAt(0);
		roomMap.put(roomSymbol, new Room(roomName));
	}

	/*takes layout file and imports the data it holds into the proper locations
	 *file should be a rectangular .csv of the board, where each element is 
	 *a 1 or two letter symbol. first letter is the room in that cell and the
	 *second letter any special part of the cell, such as secret passages, doors
	 *etc. if not proper formated, will throw exception
	 */
	public void loadLayoutConfig() throws BadConfigFormatException {	
		countRowsCols();
		generateBoard();
		
		try {
			//loads the layout file into a scanner to read
			FileReader reader = new FileReader(layoutConfigFile);
			Scanner scanner = new Scanner(reader);  

			String[] tokens;
			String token;
			for (int i = 0; i < numRows; i++) {
				tokens = scanner.nextLine().split(",");				

				for (int j = 0; j < numCols; j++) {	
					if (j < tokens.length) {
						token = tokens[j];
					} else {
						throw new BadConfigFormatException();
					}
					
					if (roomMap.get(token.charAt(0)) != null) {
						board[i][j].setRoom(roomMap.get(token.charAt(0)));
					} else {
						throw new BadConfigFormatException();
					}

					parseSecondCharacter(token, i, j);
				}
			}
			generateExits();

		} catch (FileNotFoundException e) {
			System.out.println(e);
		} 
	}

	private void parseSecondCharacter(String token, int row, int column) {
		if (token.length() > 1) {
			switch (token.charAt(1)) {
			case '<':
				board[row][column].setDoorDirection(DoorDirection.LEFT);
				break;
			case '>': 
				board[row][column].setDoorDirection(DoorDirection.RIGHT);
				break;
			case 'v': 
				board[row][column].setDoorDirection(DoorDirection.DOWN);
				break;
			case '^': 
				board[row][column].setDoorDirection(DoorDirection.UP);
				break;
			case '#':
				board[row][column].setLabel(true);
				roomMap.get(token.charAt(0)).setLabelCell(board[row][column]);
				break;
			case '*':
				board[row][column].setRoomCenter(true);
				roomMap.get(token.charAt(0)).setCenterCell(board[row][column]);
				break;
			default:
				board[row][column].setSecretPassage(token.charAt(1));
			}
		}
	}

	//fils the set of doorways to each room
	private void generateExits() {
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				if (board[i][j].isDoorway()) {
					getDoorDest(i, j).getRoom().addDoorway(board[i][j]);
				}
				if (board[i][j].isSecretPassage()) {
					board[i][j].getRoom().addDoorway(getSecretPassageDest(i, j));
				}
			}
		}
	}

	private void generateBoard() {
		// allocates the board
		board = new BoardCell[numRows][numCols];

		//allocates each cell within the board
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				board[i][j] = new BoardCell(i, j);
			}
		}
	}

	private void countRowsCols() {
		// quickly scans the file in order 
		try {
			FileReader reader = new FileReader(layoutConfigFile);
			Scanner scanner = new Scanner(reader);

			//gets the first line of a file, then puts it into a string
			//array based on values separated by commas
			String[] tokens = scanner.nextLine().split(",");
			//sets the size of the board
			numCols = tokens.length;

			//counts the number of line in the layout file, and uses it to
			//set the number of rows in the board
			numRows = 1;
			while (scanner.hasNextLine()) {
				scanner.nextLine();
				numRows++;
			}

		} catch (FileNotFoundException e) {
			System.out.println(e);
		}
	}

	/*
	 * ALL CODE BENEATH THIS POINT SHOULD BE GETTER/SETTERS
	 */


	public Set<BoardCell> getTargets() {
		return targets;
	}

	public BoardCell getCell( int row, int col ) {
		return board[row][col];
	}

	public Room getRoom(BoardCell cell) {
		return cell.getRoom();
	}

	public Room getRoom(char c) {
		return roomMap.get(c);
	}

	public void setConfigFiles(String layoutFile, String setupFile) {
		setupConfigFile = "data/" + setupFile;
		layoutConfigFile = "data/" +layoutFile;
	}

	public int getNumRows() {
		return numRows;
	}

	public int getNumColumns() {
		return numCols;
	}

	public Set<BoardCell> getAdjList(int i, int j) {
		return board[i][j].getAdjList(); 
	}


}
