Benjamin Morgan, Brendan Uebelhoer - Section A
No outside resources
